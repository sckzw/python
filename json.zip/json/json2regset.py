import sys
import json

args = sys.argv

if len( args ) < 2:
    print( 'Usage: python {} sample.json'.format( args[0] ) )
    sys.exit()

with open( args[1] ) as f:
    d = json.load( f )

adr_dic = {
    'param_a': 0x0004,
    'param_b': 0x0008
}

for k, v in d.items():
    if k == 'param_c':
        print( v )
    elif k in adr_dic:
        print( '{:#010x} = {:#010x}'.format( adr_dic[k], v ) )
    else:
        print( 'Error: Invalid parameter name {}'.format( k ) )
        sys.exit()
